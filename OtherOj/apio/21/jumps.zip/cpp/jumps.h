#include <vector>

void init(int N, std::vector<int> H);
int minimum_jumps(int A, int B, int C, int D);
