#include "my_strcmp.h"

int my_strcmp(char *a, char *b) {
	return 0;
}
