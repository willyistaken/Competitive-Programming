
int my_strcmp(char *a, char *b);
